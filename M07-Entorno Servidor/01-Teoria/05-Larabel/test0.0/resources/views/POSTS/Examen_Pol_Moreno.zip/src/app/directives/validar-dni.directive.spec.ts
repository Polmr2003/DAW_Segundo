import { ValidarDniDirective } from './validar-dni.directive';

describe('ValidarDniDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarDniDirective();
    expect(directive).toBeTruthy();
  });
});
