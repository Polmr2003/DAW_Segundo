class User {
    #nom;
    #cognoms;
    #email;
    #password;
    #dni;
  
    constructor(email="", password="", nom="", cognoms="", dni="") {
      
      this.#email = email;
      this.#password = password;
      this.#nom = nom;
      this.#cognoms = cognoms;
      this.#dni = dni;
    }
  
    get nom() {
      return this.#nom;
    }
  
    set nom(nouNom) {
      this.#nom = nouNom;
    }
  
    get cognoms() {
      return this.#cognoms;
    }
  
    set cognoms(nousCognoms) {
      this.#cognoms = nousCognoms;
    }
  
    get email() {
      return this.#email;
    }
  
    set email(nouEmail) {
      this.#email = nouEmail;
    }
  
    get password() {
      return this.#password;
    }
  
    set password(novaContrasenya) {
      this.#password = novaContrasenya;
    }
  
    get dni() {
      return this.#dni;
    }
  
    set dni(nouDni) {
      this.#dni = nouDni;
    }
  
    toObject() {
      return {
        email: this.#email,
        password: this.#password
      };
    }
  }


  