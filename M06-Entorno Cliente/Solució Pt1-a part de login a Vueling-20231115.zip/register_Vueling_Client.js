document.addEventListener("DOMContentLoaded", function () {

//mostrar el username y el password en un div con id results y validar credenciales
document.getElementById("btnLogin").addEventListener("click", function () {

    let email = document.getElementById("username").value;
    let password = document.getElementById("userpass").value;

    let user = new User(email,password);
    console.log(user.toObject());
      // Realizar la solicitud POST usando fetch
      fetch('http://localhost:3000/vueling/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(user.toObject())
      })
        .then(response => response.json())
        .then(data => {
          // Manejar la respuesta del servidor
          if (data.success) {
            document.getElementById("LoginMessage").innerHTML = "USUARI CORRECTE";
            sessionStorage.setItem('logueado', true);
            
            // Redirigir a la página de inicio o realizar alguna acción adicional
          } else {
            document.getElementById("LoginMessage").innerHTML = "CREDENCIALS INCORRECTES";
            // Mostrar un mensaje de error al usuario o realizar alguna acción adicional
          }
        })
        .catch(error => {
          console.error('Error al realizar la solicitud:', error);
        });
});


//declaramos variables para validar y el array que usaremos
let correctNom = false;
let correctCognom = false;
let correctMail = false;
let correctPassowrd = false;
let correctPassword2 = false;
let correctDni = false;

//validamos el nombre
document.getElementById("nom").addEventListener("blur", function () {
    let nom = document.getElementById("nom").value;
    let patron = /^[a-zñç' àáèéòóúùìí]+$/;
    if (!patron.test(nom.toLowerCase())) {
        document.getElementById("nomError").innerHTML = "Nomes pot ser lletra";
        correctNom = false;
    } else {
        document.getElementById("nomError").innerHTML = "";
        correctNom = true;

        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    }
});

//validamos el apellido
document.getElementById("cognom").addEventListener("blur", function () {
    let cognom = document.getElementById("cognom").value;
    let patron = /^[a-zñç' àáèéòóúùìí]+$/;

    if (!patron.test(cognom.toLowerCase())) {
        document.getElementById("cognomError").innerHTML = "Nomes pot ser lletra";
        correctCognom = false;
    } else {
        document.getElementById("cognomError").innerHTML = "";
        correctCognom = true;

        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    }
});

//validamos el mail
document.getElementById("mail").addEventListener("blur", function () {
    let mail = document.getElementById("mail").value;
    let patronEmail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

    if (!patronEmail.test(mail)) {
        document.getElementById("mailError").innerHTML = "El mail no es valid";
        correctMail = false;
    } else {
        document.getElementById("mailError").innerHTML = "";
        correctMail = true;

        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    }

});

//validamos el password
document.getElementById("password").addEventListener("blur", function () {
    let contra = document.getElementById("password").value;
    if (contra.length < 5) {
        document.getElementById("passwordError").innerHTML =
            "Te que tenir minim 5 caracters";
        correctPassowrd = false;
    } else {
        document.getElementById("passwordError").innerHTML = "";
        correctPassowrd = true;

        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    }
});

//validamos la repetición del password
document.getElementById("repeatPassword").addEventListener("blur", function () {
    let contra2 = document.getElementById("repeatPassword").value;
    let contra = document.getElementById("password").value;
    if (contra2 != contra) {
        document.getElementById("repeatPasswordError").innerHTML =
            "Els passwords no coincideixen";
        correctPassword2 = false;
    } else {
        document.getElementById("repeatPasswordError").innerHTML = "";
        correctPassword2 = true;
        validarTodo++;
        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    }
});
//validamos el dni
document.getElementById("dni").addEventListener("blur", function () {
    let dni = document.getElementById("dni").value;
    let num = dni.substr(0, 8);
    let lletra = dni.substr(-1);

    if (verificaDNI(num, lletra)) {
        document.getElementById("dniIncorrecte").innerHTML = "";
        correctDni = true;

        validar(correctNom, correctCognom, correctMail, correctPassowrd, correctPassword2, correctDni);
    } else {
        document.getElementById("dniIncorrecte").innerHTML = "DNI incorrecte";
        correctDni = false;
    }
});


//validar credenciales boton registro y mostrar si se ha registrado correctamente y guardamos los datos en un array
document.getElementById("btnRegistre").addEventListener("click", function () {


    let mail = document.getElementById("mail").value;
    let contra = document.getElementById("password").value;


    if (correctNom == true && correctCognom == true && correctMail == true && correctPassowrd == true && correctPassword2 == true && correctDni == true) {
        document.getElementById("RegisterMessage").innerHTML = "USUARI ENREGISTRAT CORRECTAMENT";
    } else {
        document.getElementById("RegisterMessage").innerHTML = "";
    }

    if (correctNom == true && correctCognom == true && correctMail == true && correctPassowrd == true && correctPassword2 == true && correctDni == true) {
        usuaris.push(mail);
        contrasenyes.push(contra);
    }

});
});