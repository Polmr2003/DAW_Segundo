INSERT INTO vueling.`user` (Nombre,Apellidos,Email,Contraseña,DNI) VALUES
	 ('nombr3','apellido3','email3@gmail.com','pass3','48537221E'),
	 ('nombre1','apellido1','email1@gmail.com','pass1','46479814B'),
	 ('nombre2','apellido2','email2@gmail.com','pass2','01157095B');
